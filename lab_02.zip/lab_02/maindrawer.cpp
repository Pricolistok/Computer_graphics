#include "maindrawer.h"

void MyDrawWidget::paintEvent(QPaintEvent *event)
{
    double offset_to_center_x = 500, offset_to_center_y = 300;

    QPainter painter(this);

    Q_UNUSED(event);
    painter.end();

    painter.begin(this);
    painter.setPen(Qt::white);

    for (double i = -10; i <= 10; i += 0.1)
    {
        painter.drawEllipse(QPoint(i + offset_to_center_x, exp(i) + offset_to_center_y), 1, 1);
    }
}