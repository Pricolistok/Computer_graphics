#ifndef MAINDRAWER_H
#define MAINDRAWER_H

#include <QPainter>
#include <QMainWindow>
#include <math.h>

class MyDrawWidget : public QWidget
{
    Q_OBJECT

public:
    explicit MyDrawWidget(QWidget *parent = nullptr);

protected:
    void paintEvent(QPaintEvent *event) override;
};

#endif
